# Contributing to DRISTI

Thanks for your interest! Please:
1. Open an issue first to discuss changes.
2. Use feature branches and PRs.
3. Follow the code style via `ruff` and `black` (optional).
4. Add/maintain tests with `pytest`.

## Dev Setup
```bash
pip install -r requirements.txt
pip install -U ruff black pytest
pre-commit install
```
