import streamlit as st

st.set_page_config(page_title="DRISTI Dashboard", layout="wide")
st.title("DRISTI — Authority Dashboard (Prototype)")
st.write("🔧 Placeholder app. Add heatmaps, asset tracking, and alerts here.")
