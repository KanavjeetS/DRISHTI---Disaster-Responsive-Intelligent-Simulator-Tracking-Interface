import gymnasium as gym
import numpy as np

class CrowdEnv(gym.Env):
    metadata = {"render_modes": ["human"], "render_fps": 15}

    def __init__(self, grid_shape=(20, 20), max_steps=300):
        super().__init__()
        self.grid_shape = grid_shape
        self.max_steps = max_steps
        self.observation_space = gym.spaces.Box(0.0, 1.0, shape=(grid_shape[0], grid_shape[1], 3), dtype=np.float32)
        self.action_space = gym.spaces.Discrete(5)  # e.g., {stay, up, down, left, right}
        self.reset()

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.t = 0
        self.state = np.zeros((*self.grid_shape, 3), dtype=np.float32)
        return self.state, {}

    def step(self, action):
        self.t += 1
        reward = -0.01
        terminated = self.t >= self.max_steps
        truncated = False
        info = {}
        return self.state, reward, terminated, truncated, info

    def render(self):
        pass
