import time

def main():
    print("Running DRISTI demo simulation...")
    for t in range(5):
        print(f"tick={t}")
        time.sleep(0.2)
    print("Demo complete. Replace with real simulation.")

if __name__ == "__main__":
    main()
