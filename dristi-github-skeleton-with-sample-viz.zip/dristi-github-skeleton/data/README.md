# DRISTI Dataset

This folder contains a **sample subset** of the dataset (2 images per split).  
The full dataset is too large for direct GitHub storage.  

## Structure
```
data/sample_dataset/
  train/   # Training images + labels
  valid/   # Validation images + labels
  test/    # Test images + labels
```

Each image may have a `.txt` annotation file in YOLO format.

## Full Dataset
- Original archive contains thousands of files (`train/`, `valid/`, `test/`).
- Please store the complete dataset externally (e.g., Google Drive, HuggingFace Datasets, or Kaggle).

## Usage
Example (YOLOv8 with ultralytics):
```bash
yolo detect train data=data/sample_dataset data.yaml --model=yolov8n.pt --epochs=10
```
