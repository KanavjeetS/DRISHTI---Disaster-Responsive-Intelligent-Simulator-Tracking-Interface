# Data Readme

Place raw data under `data/raw/` and processed datasets under `data/processed/`.

- Document the source, licensing, and schema for each dataset
- Do not commit large files; consider Git LFS if necessary
