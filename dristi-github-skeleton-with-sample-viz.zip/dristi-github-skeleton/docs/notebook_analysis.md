# Notebook Analysis: Ujjain Hackathon (2).ipynb

- Total cells: 5
- Code cells: 5, Markdown cells: 0
- Unique imports: gymnasium, numpy, os, tkinter
- Unique from-imports: PIL, gymnasium, pathlib, stable_baselines3, tkinter, ultralytics
- Defined functions: __init__, annotate_folder, pick_folder_and_annotate, reset, step
- Defined classes: CrowdEvacEnv
- Key libraries detected: gym, gymnasium, numpy, stable_baselines3